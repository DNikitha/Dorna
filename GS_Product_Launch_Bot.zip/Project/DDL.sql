USE [DXC]

--Creating Config_Table
CREATE TABLE [dbo].[Config_Table](
	[ConfigName] [varchar](max) NULL,
	[ConfigValue] [varchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]