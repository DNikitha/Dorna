USE [DXC]
GO

--inserting the values into Config_Table table

INSERT INTO Config_Table([ConfigName],[ConfigValue]) VALUES('Email_Body',',Greetings !
The new Mobile you are waiting for GM Mobile is available from 3pm Wednesday 12-Aug for sale @ greatshopping.com
Enjoy Happy Shopping !
Team Great Shopping.')
INSERT INTO Config_Table([ConfigName],[ConfigValue]) VALUES('Greeting','Dear')
INSERT INTO Config_Table([ConfigName],[ConfigValue]) VALUES('EmailCell','E')
INSERT INTO Config_Table([ConfigName],[ConfigValue]) VALUES('WhatsappCell','D')
INSERT INTO Config_Table([ConfigName],[ConfigValue]) VALUES('WhatsappImage','C:\Project\ProductLaunch.jpg')
INSERT INTO Config_Table([ConfigName],[ConfigValue]) VALUES('EmailImage','C:\Project\Mail_Img.png')
INSERT INTO Config_Table([ConfigName],[ConfigValue]) VALUES('OutputFile','C:\Project\Output.xlsx')
INSERT INTO Config_Table([ConfigName],[ConfigValue]) VALUES('EmailSubject','Launch Of GM Mobile')
INSERT INTO Config_Table([ConfigName],[ConfigValue]) VALUES('CountryCode','91')
INSERT INTO Config_Table([ConfigName],[ConfigValue]) VALUES('WhatsappLink','https://api.whatsapp.com/send?phone=')
INSERT INTO Config_Table([ConfigName],[ConfigValue]) VALUES('Browser','https://web.whatsapp.com/')
INSERT INTO Config_Table([ConfigName],[ConfigValue]) VALUES('SheetName','CustomerDetails')


